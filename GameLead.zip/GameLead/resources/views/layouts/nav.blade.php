<!-- header -->
<div class="header">
		<div class="w3layouts_header_left">
				<div class="top-nav-text">
						<p>Call Us : <span class="call">+21 8578 8867 889</span></p>
						<p>Email Us : <span class="mail"><a href="mailto:info@example.com">gamelead.id@gmail.com</a></span></p>
					</div>
		</div>
		<div class="w3layouts_header_right">
			     <form action="#" method="post">
						<input name="Search heare" type="search" placeholder="Search" required="">
					
						<input type="submit" value="">
					</form>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="w3_navigation">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<div class="w3_navigation_pos">
						<h1><a href="index.html"><span>GameLead</span></a></h1>
					</div>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="cl-effect-5" id="cl-effect-5">
						<ul class="nav navbar-nav">
							<li class="active"><a href="index.html"><span data-hover="Home">Home</span></a></li>

							<li><a href="/about" class="scroll"><span data-hover="Learn">Learn</span></a></li>
							<li><a href="/services" class="scroll"><span data-hover="Tournament">Tournament</span></a></li>
							<li><a href="/work" class="scroll"><span data-hover="FindTeam">FindTeam</span></a></li>
							@if (Route::has('login'))
							@auth
							<li><a href="/profile" class="scroll"><span data-hover="Profile">Profile</span></a></li>
							@else
							<li><a href="{{ route('login') }}" class="scroll"><span data-hover="Login">Login</span></a></li>
                   			 @endauth
							@endif
						</ul>
					</nav>
				</div>
			</nav>	
		</div>
	</div>
<!-- //header -->