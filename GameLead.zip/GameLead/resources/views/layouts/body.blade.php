@include('layouts.nav')

    @yield('content')

@include('layouts.footer')